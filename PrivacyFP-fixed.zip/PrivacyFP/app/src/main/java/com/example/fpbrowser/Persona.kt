package com.example.fpbrowser

import org.json.JSONObject
import java.security.SecureRandom

/**
 * One stable, internally consistent "device identity". Everything a site can observe together (Android version,
 * GPU, core count, noise seed) is drawn together from one real-world device class, so the pieces never contradict
 * each other. [locale]/[timezone] are null = follow the real system; they are only set to match a proxy's exit IP
 * (a random timezone that disagrees with your IP is worse than none).
 */
data class Persona(
    val seed: String,
    val device: String,
    val androidVersion: Int,
    val cores: Int,
    val glVendor: String,
    val glRenderer: String,
    val locale: String?,
    val timezone: String?
) {
    fun label() = "$device · Android $androidVersion"

    /**
     * Takes the engine's REAL user agent and swaps only the Android version, so the Gecko/Firefox version always
     * matches the engine that is actually running (a mismatched version is a classic detection tell).
     * Firefox never exposes the phone model in its UA, so neither do we. Returns null if the shape is unexpected.
     */
    fun applyUa(realUa: String?): String? {
        if (realUa.isNullOrBlank()) return null
        val re = Regex("Android \\d+(\\.\\d+)*")
        if (!re.containsMatchIn(realUa)) return null
        return re.replaceFirst(realUa, "Android $androidVersion")
    }

    fun withGeo(tz: String?, loc: String?) = copy(timezone = tz, locale = loc)

    fun toJson(): JSONObject = JSONObject()
        .put("seed", seed).put("device", device).put("android", androidVersion).put("cores", cores)
        .put("glVendor", glVendor).put("glRenderer", glRenderer)
        .put("locale", locale ?: JSONObject.NULL).put("tz", timezone ?: JSONObject.NULL)

    /** What the page-side extension needs. */
    fun forExtension(): JSONObject = JSONObject()
        .put("seed", seed).put("cores", cores).put("glVendor", glVendor).put("glRenderer", glRenderer)
        .put("canvas", true).put("webgl", true).put("audio", true)

    companion object {
        private class Dev(val name: String, val vendor: String, val renderer: String, val cores: Int, val aMin: Int, val aMax: Int)

        // GPU strings are exactly what Firefox reports as UNMASKED_VENDOR/RENDERER on these chips.
        private val devices = listOf(
            Dev("Pixel 6", "ARM", "Mali-G78", 8, 13, 16),
            Dev("Pixel 7", "ARM", "Mali-G710", 8, 13, 16),
            Dev("Pixel 7 Pro", "ARM", "Mali-G710", 8, 13, 16),
            Dev("Pixel 8", "ARM", "Mali-G715", 8, 14, 16),
            Dev("Pixel 8 Pro", "ARM", "Mali-G715", 8, 14, 16),
            Dev("Pixel 9", "ARM", "Mali-G715", 8, 15, 16),
            Dev("Galaxy S21", "Qualcomm", "Adreno (TM) 660", 8, 13, 15),
            Dev("Galaxy S22", "Qualcomm", "Adreno (TM) 730", 8, 13, 16),
            Dev("Galaxy S23", "Qualcomm", "Adreno (TM) 740", 8, 13, 16),
            Dev("Galaxy S24", "Qualcomm", "Adreno (TM) 750", 8, 14, 16),
            Dev("Galaxy A54", "ARM", "Mali-G68", 8, 13, 16),
            Dev("Galaxy A34", "ARM", "Mali-G68", 8, 13, 15),
            Dev("Galaxy A15", "ARM", "Mali-G52", 8, 14, 15),
            Dev("OnePlus 10 Pro", "Qualcomm", "Adreno (TM) 730", 8, 12, 14),
            Dev("OnePlus 11", "Qualcomm", "Adreno (TM) 740", 8, 13, 15),
            Dev("Xiaomi 13", "Qualcomm", "Adreno (TM) 740", 8, 13, 15),
            Dev("Xiaomi 14", "Qualcomm", "Adreno (TM) 750", 8, 14, 15),
            Dev("Redmi Note 12", "Qualcomm", "Adreno (TM) 610", 8, 12, 14),
            Dev("POCO X5 Pro", "Qualcomm", "Adreno (TM) 642L", 8, 12, 14),
            Dev("Moto G84", "Qualcomm", "Adreno (TM) 619", 8, 13, 15),
            Dev("Nothing Phone (2)", "Qualcomm", "Adreno (TM) 730", 8, 13, 15),
            Dev("Xperia 1 V", "Qualcomm", "Adreno (TM) 740", 8, 13, 15),
            Dev("Redmi A1", "Imagination Technologies", "PowerVR Rogue GE8320", 4, 12, 12)
        )

        /** A brand-new identity. Keeps nothing from the old one except (optionally) the proxy-derived locale/timezone. */
        fun random(keepGeoFrom: Persona? = null): Persona {
            val r = SecureRandom()
            val d = devices[r.nextInt(devices.size)]
            val seedBytes = ByteArray(16).also { r.nextBytes(it) }
            val seed = seedBytes.joinToString("") { "%02x".format(it) }
            val android = d.aMin + r.nextInt(d.aMax - d.aMin + 1)
            return Persona(seed, d.name, android, d.cores, d.vendor, d.renderer, keepGeoFrom?.locale, keepGeoFrom?.timezone)
        }

        fun fromJson(o: JSONObject) = Persona(
            o.getString("seed"), o.getString("device"), o.getInt("android"), o.getInt("cores"),
            o.getString("glVendor"), o.getString("glRenderer"),
            if (o.isNull("locale")) null else o.getString("locale"),
            if (o.isNull("tz")) null else o.getString("tz")
        )
    }
}
