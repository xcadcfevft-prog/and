package com.example.fpbrowser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** One isolated browsing environment: its own cookies/storage (contextId), its own device identity, its own network exit. */
class Profile(
    val id: String,
    var name: String,
    var persona: Persona,
    var proxy: String = "",          // socks5://user:pass@host:port | http://... | host:port:user:pass ; "" = direct
    var proxyPool: String = "",      // one proxy per line, used by "random IP"
    var epoch: Int = 0,              // bumped on "random device": new cookie jar, old one is wiped
    var webrtc: Boolean = false,
    var uniform: Boolean = false     // true = Tor-style "everyone looks the same" (Gecko RFP) instead of a random device
) {
    fun contextId() = "p_${id}_$epoch"
    fun upstream(): ProxyRelay.Upstream? = try { ProxyRelay.Upstream.parse(proxy) } catch (e: Exception) { null }
    fun poolEntries(): List<String> = proxyPool.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("persona", persona.toJson())
        .put("proxy", SecretBox.enc(proxy)).put("pool", SecretBox.enc(proxyPool))
        .put("epoch", epoch).put("webrtc", webrtc).put("uniform", uniform)

    companion object {
        fun fromJson(o: JSONObject) = Profile(
            o.getString("id"), o.getString("name"), Persona.fromJson(o.getJSONObject("persona")),
            SecretBox.dec(o.optString("proxy", "")), SecretBox.dec(o.optString("pool", "")),
            o.optInt("epoch", 0), o.optBoolean("webrtc", false), o.optBoolean("uniform", false)
        )
        fun create(name: String) = Profile(UUID.randomUUID().toString().replace("-", "").take(12), name, Persona.random())
    }
}

class Profiles(ctx: Context) {
    private val sp = ctx.getSharedPreferences("profiles_v3", Context.MODE_PRIVATE)
    val list = mutableListOf<Profile>()
    var currentId: String = ""

    init {
        try {
            val a = JSONArray(sp.getString("list", "[]"))
            for (i in 0 until a.length()) list += Profile.fromJson(a.getJSONObject(i))
        } catch (e: Exception) { list.clear() }
        if (list.isEmpty()) list += Profile.create("环境 1")
        currentId = sp.getString("current", null)?.takeIf { id -> list.any { it.id == id } } ?: list[0].id
        save()
    }

    val current: Profile get() = list.first { it.id == currentId }

    fun add(): Profile { val p = Profile.create("环境 ${list.size + 1}"); list += p; currentId = p.id; save(); return p }
    fun select(id: String) { currentId = id; save() }

    /** Removes a profile (never the last one). Returns it so the caller can wipe its data. */
    fun remove(id: String): Profile? {
        if (list.size <= 1) return null
        val p = list.firstOrNull { it.id == id } ?: return null
        list.remove(p)
        sp.edit().remove("tabs_$id").commit()
        if (currentId == id) currentId = list[0].id
        save()
        return p
    }

    fun save() {
        val a = JSONArray(); list.forEach { a.put(it.toJson()) }
        // commit(), not apply(): the process is killed right after a profile change, an async write could be lost
        sp.edit().putString("list", a.toString()).putString("current", currentId).commit()
    }

    // ---- storage wipe queue: survives the restart, executed at the next engine start before any tab opens ----
    fun markWipe(ctx: String) {
        val s = (sp.getStringSet("wipe", emptySet()) ?: emptySet()).toMutableSet()
        s.add(ctx); sp.edit().putStringSet("wipe", s).commit()
    }
    fun pendingWipes(): Set<String> = (sp.getStringSet("wipe", emptySet()) ?: emptySet()).toSet()
    fun doneWipe(ctx: String) {
        val s = (sp.getStringSet("wipe", emptySet()) ?: emptySet()).toMutableSet()
        s.remove(ctx); sp.edit().putStringSet("wipe", s).commit()
    }

    // ---- open tabs per profile, so an engine restart brings everything back ----
    fun saveTabs(id: String, urls: List<String>, active: Int) {
        val o = JSONObject().put("urls", JSONArray(urls)).put("active", active)
        sp.edit().putString("tabs_$id", SecretBox.enc(o.toString())).commit()   // URLs can carry tokens: encrypt at rest
    }

    fun loadTabs(id: String): Pair<List<String>, Int> {
        return try {
            val o = JSONObject(SecretBox.dec(sp.getString("tabs_$id", "") ?: ""))
            val a = o.getJSONArray("urls")
            Pair((0 until a.length()).map { a.getString(it) }, o.optInt("active", 0))
        } catch (e: Exception) { Pair(emptyList(), 0) }
    }

    fun clearTabs(id: String) { sp.edit().remove("tabs_$id").commit() }
}
