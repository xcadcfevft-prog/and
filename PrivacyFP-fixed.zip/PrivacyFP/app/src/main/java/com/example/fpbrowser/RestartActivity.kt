package com.example.fpbrowser

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Process

/** Lives in its own process (:restart) so it survives the main process being killed, then relaunches the browser. */
class RestartActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        @Suppress("DEPRECATION")
        val next = intent.getParcelableExtra<Intent>("next")
        if (next != null) startActivity(next)
        finish()
        Process.killProcess(Process.myPid())
    }
}
