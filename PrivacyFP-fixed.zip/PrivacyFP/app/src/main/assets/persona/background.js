"use strict";
// PrivacyFP persona loader (background page of the built-in extension).
//
//   [app]  <-- native messaging, app name "browser" -->  [this page]  --contentScripts.register-->  every web page
//
// Why this file looks defensive (these were the real causes of the "设备伪装未就绪 / 等待超时" dialog):
//  1. GeckoView can only hand primitive JSON values (String / Boolean / numbers) back to JS. The old app answered
//     with an org.json.JSONObject; GeckoView silently drops such a reply, so the promise of
//     sendNativeMessage() NEVER settled (neither resolved nor rejected) and the old loop below hung on its very first
//     `await` forever -> "ready" was never sent. The app now answers with a JSON *string*, parsed here.
//  2. Messages sent before the app has attached its delegate are queued by GeckoView, so a call may take a while --
//     or never settle. Every call therefore has its own timeout and is retried.
//  3. Failures used to be swallowed by an empty catch. They are now reported to the app (type "status"), which shows
//     the last stage in its warning dialog, and they go to the console as well.
//  4. The old code registered the content script again on every retry and fetched inject.js outside of any try/catch.

const NATIVE = "browser";
const MARKER = "const P = __PERSONA__;";
const CALL_TIMEOUT_MS = 5000;        // one native call
const MAX_PERSONA_TRIES = 300;       // x ~0.5 s => the app has ~2.5 min to attach its delegate (the app itself gives up earlier)
const MAX_REGISTER_TRIES = 4;
const MAX_READY_TRIES = 8;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function withTimeout(promise, ms, what) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(what + ": no answer from app within " + ms + " ms")), ms);
    promise.then(
      (v) => { clearTimeout(t); resolve(v); },
      (e) => { clearTimeout(t); reject(e); }
    );
  });
}

function call(message) {
  let p;
  try { p = browser.runtime.sendNativeMessage(NATIVE, message); }
  catch (e) { return Promise.reject(e); }
  return withTimeout(Promise.resolve(p), CALL_TIMEOUT_MS, message.type);
}

const reported = new Set();
// Best effort: tell the app where we are. Never throws, never blocks the boot sequence.
function report(stage, detail) {
  const text = detail ? stage + ": " + detail : stage;
  try { console.log("[persona] " + text); } catch (e) { /* ignore */ }
  if (reported.has(text) || reported.size > 40) return;
  reported.add(text);
  try {
    const p = browser.runtime.sendNativeMessage(NATIVE, { type: "status", stage: String(stage), detail: String(detail || "") });
    if (p && p.catch) p.catch(() => {});
  } catch (e) { /* ignore */ }
}

// The app replies with a JSON string. Also accepts an already-parsed object, in case a future app build changes that.
function parsePersona(reply) {
  let r = reply;
  if (typeof r === "string") {
    try { r = JSON.parse(r); } catch (e) { return null; }
  }
  return r && typeof r === "object" && r.seed ? r : null;
}

async function loadInjectSource() {
  const res = await fetch(browser.runtime.getURL("inject.js"));
  const src = await res.text();
  if (!src.includes(MARKER)) throw new Error("inject.js: persona marker missing");
  return src;
}

let registration = null;   // handle of the currently registered content script

async function register(persona) {
  const src = await loadInjectSource();
  const code = src.replace(MARKER, () => "const P = " + JSON.stringify(persona) + ";");
  if (registration) {                                  // never stack two injectors
    try { await registration.unregister(); } catch (e) { /* ignore */ }
    registration = null;
  }
  registration = await browser.contentScripts.register({
    matches: ["<all_urls>"],
    js: [{ code }],
    runAt: "document_start",
    allFrames: true,
    matchAboutBlank: true
  });
}

async function fetchPersona() {
  let lastError = "";
  for (let i = 1; i <= MAX_PERSONA_TRIES; i++) {
    try {
      const reply = await call({ type: "getPersona", ua: navigator.userAgent });
      if (reply === "skip") return "skip";             // the user chose "continue without disguise" for this run
      const persona = parsePersona(reply);
      if (persona) return persona;
      lastError = "unreadable reply (" + typeof reply + ")";
      report("getPersona", lastError);
    } catch (e) {
      lastError = String((e && e.message) || e);
      if (i === 3 || i % 20 === 0) report("getPersona", "try " + i + " failed: " + lastError);
    }
    await sleep(500);
  }
  throw new Error("no persona after " + MAX_PERSONA_TRIES + " tries (" + lastError + ")");
}

async function boot() {
  report("background-started");

  const persona = await fetchPersona();
  if (persona === "skip") { report("skipped"); return; }
  report("persona-received");

  let lastError = "";
  let registered = false;
  for (let i = 1; i <= MAX_REGISTER_TRIES && !registered; i++) {
    try { await register(persona); registered = true; }
    catch (e) { lastError = String((e && e.message) || e); report("register-failed", "try " + i + ": " + lastError); await sleep(300); }
  }
  if (!registered) throw new Error("content script registration failed (" + lastError + ")");
  report("content-script-registered");

  // Give GeckoView a moment to hand the new registration to the content process before the first page loads.
  await sleep(250);

  for (let i = 1; i <= MAX_READY_TRIES; i++) {
    try { await call({ type: "ready" }); return; }
    catch (e) { await sleep(400); }
  }
  // Not fatal: the app may have received it and only the acknowledgement got lost.
  report("ready-not-acknowledged");
}

boot().catch((e) => report("boot-failed", String((e && e.message) || e)));
