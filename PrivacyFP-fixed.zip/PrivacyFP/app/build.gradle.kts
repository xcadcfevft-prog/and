plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.fpbrowser"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.fpbrowser"
        minSdk = 26; targetSdk = 35; versionCode = 4; versionName = "3.1-gecko"
        ndk { abiFilters += listOf("arm64-v8a") }   // modern phones only; keeps the APK smaller
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs { useLegacyPackaging = true } }
}
// Pin an exact version for reproducible builds, e.g. "131.0.20241016174836"
// (see https://maven.mozilla.org/?prefix=maven2/org/mozilla/geckoview/geckoview/)
val geckoVersion = providers.gradleProperty("geckoVersion").getOrElse("+")
dependencies { implementation("org.mozilla.geckoview:geckoview:$geckoVersion") }
